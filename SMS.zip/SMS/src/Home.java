
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;


public class Home extends javax.swing.JFrame {

    public Home() {
        initComponents();
        setLocationRelativeTo(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
           
        getUser();
    }

    private void getUser(){
        smsGUI obj = new smsGUI();
        username.setText(obj.adminId);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        logoutButton = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        username = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        managestdButton = new javax.swing.JButton();
        admButton = new javax.swing.JButton();
        stdrecordButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        feesubmitButton = new javax.swing.JButton();
        feeReminderButton = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        classButton = new javax.swing.JButton();
        resultButton = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        admitcardButton = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setBackground(new java.awt.Color(0, 0, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(0, 0, 255));

        jLabel5.setBackground(new java.awt.Color(0, 0, 255));
        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu2.png"))); // NOI18N

        jLabel6.setBackground(new java.awt.Color(102, 102, 102));
        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(153, 153, 153));
        jLabel6.setText("MENU");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel5))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 170, 60));

        logoutButton.setBackground(new java.awt.Color(0, 0, 255));
        logoutButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/logout.jpg"))); // NOI18N
        logoutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutButtonActionPerformed(evt);
            }
        });
        jPanel3.add(logoutButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1810, 10, 80, 70));

        jLabel8.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 204, 0));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Logged in as");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1610, 20, 110, 20));

        username.setBackground(new java.awt.Color(255, 255, 255));
        username.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        username.setForeground(new java.awt.Color(255, 255, 255));
        username.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(username, new org.netbeans.lib.awtextra.AbsoluteConstraints(1620, 40, 90, 30));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 26)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(113, 113, 113));
        jLabel1.setText("SETTING");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 680, -1, 40));

        managestdButton.setBackground(new java.awt.Color(153, 153, 153));
        managestdButton.setFont(new java.awt.Font("Tahoma", 1, 17)); // NOI18N
        managestdButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/managestudent.png"))); // NOI18N
        managestdButton.setText("MODIFY");
        managestdButton.setBorder(null);
        managestdButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        managestdButton.setIconTextGap(40);
        managestdButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                managestdButtonActionPerformed(evt);
            }
        });
        jPanel2.add(managestdButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 280, 75));

        admButton.setBackground(new java.awt.Color(153, 153, 153));
        admButton.setFont(new java.awt.Font("Tahoma", 1, 17)); // NOI18N
        admButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/admission.png"))); // NOI18N
        admButton.setText("ADMISSION");
        admButton.setBorder(null);
        admButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        admButton.setIconTextGap(15);
        admButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                admButtonActionPerformed(evt);
            }
        });
        jPanel2.add(admButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 280, 75));

        stdrecordButton.setBackground(new java.awt.Color(153, 153, 153));
        stdrecordButton.setFont(new java.awt.Font("Tahoma", 1, 17)); // NOI18N
        stdrecordButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/studentrecord.png"))); // NOI18N
        stdrecordButton.setText("RECORDS");
        stdrecordButton.setBorder(null);
        stdrecordButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        stdrecordButton.setIconTextGap(30);
        stdrecordButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stdrecordButtonActionPerformed(evt);
            }
        });
        jPanel2.add(stdrecordButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 280, 75));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 26)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(113, 113, 113));
        jLabel2.setText("STUDENT");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 40));

        feesubmitButton.setBackground(new java.awt.Color(153, 153, 153));
        feesubmitButton.setFont(new java.awt.Font("Tahoma", 1, 17)); // NOI18N
        feesubmitButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/fees-icon.jpg"))); // NOI18N
        feesubmitButton.setText("SUBMISSION");
        feesubmitButton.setBorder(null);
        feesubmitButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        feesubmitButton.setIconTextGap(15);
        feesubmitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                feesubmitButtonActionPerformed(evt);
            }
        });
        jPanel2.add(feesubmitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 280, 75));

        feeReminderButton.setBackground(new java.awt.Color(153, 153, 153));
        feeReminderButton.setFont(new java.awt.Font("Tahoma", 1, 17)); // NOI18N
        feeReminderButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/reminder.png"))); // NOI18N
        feeReminderButton.setText("REMINDER");
        feeReminderButton.setBorder(null);
        feeReminderButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        feeReminderButton.setIconTextGap(40);
        feeReminderButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                feeReminderButtonActionPerformed(evt);
            }
        });
        jPanel2.add(feeReminderButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 390, 280, 75));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 26)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(113, 113, 113));
        jLabel3.setText("FEES");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, -1, 40));

        classButton.setBackground(new java.awt.Color(153, 153, 153));
        classButton.setFont(new java.awt.Font("Tahoma", 1, 17)); // NOI18N
        classButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/class-icon.png"))); // NOI18N
        classButton.setText("MANAGE CLASS");
        classButton.setBorder(null);
        classButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        classButton.setIconTextGap(20);
        classButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                classButtonActionPerformed(evt);
            }
        });
        jPanel2.add(classButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 730, 280, 75));

        resultButton.setBackground(new java.awt.Color(153, 153, 153));
        resultButton.setFont(new java.awt.Font("Tahoma", 1, 17)); // NOI18N
        resultButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/result.png"))); // NOI18N
        resultButton.setText("RESULT");
        resultButton.setBorder(null);
        resultButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        resultButton.setIconTextGap(45);
        resultButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resultButtonActionPerformed(evt);
            }
        });
        jPanel2.add(resultButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 590, 280, 75));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 26)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(113, 113, 113));
        jLabel4.setText("EXAM");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 480, -1, 40));

        admitcardButton.setBackground(new java.awt.Color(153, 153, 153));
        admitcardButton.setFont(new java.awt.Font("Tahoma", 1, 17)); // NOI18N
        admitcardButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/admit card.jpg"))); // NOI18N
        admitcardButton.setText("ADMIT CARD");
        admitcardButton.setBorder(null);
        admitcardButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        admitcardButton.setIconTextGap(15);
        admitcardButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                admitcardButtonActionPerformed(evt);
            }
        });
        jPanel2.add(admitcardButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 520, 280, 75));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/school-background.jpg"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 1655, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 930, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void managestdButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_managestdButtonActionPerformed
        manageStudent obj = new manageStudent();
        obj.setVisible(true);
    }//GEN-LAST:event_managestdButtonActionPerformed

    private void admButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_admButtonActionPerformed
        admission obj = new admission();
        obj.setVisible(true);
    }//GEN-LAST:event_admButtonActionPerformed

    private void stdrecordButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stdrecordButtonActionPerformed
        studentRecords obj = new studentRecords();
        obj.setVisible(true);
    }//GEN-LAST:event_stdrecordButtonActionPerformed

    private void feesubmitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_feesubmitButtonActionPerformed
        feeFrame obj = new feeFrame();
        obj.setVisible(true);
    }//GEN-LAST:event_feesubmitButtonActionPerformed

    private void feeReminderButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_feeReminderButtonActionPerformed
        feeCheck obj = new feeCheck();
        obj.setVisible(true);
    }//GEN-LAST:event_feeReminderButtonActionPerformed

    private void classButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_classButtonActionPerformed
        manage_class obj = new manage_class();
        obj.setVisible(true);
    }//GEN-LAST:event_classButtonActionPerformed

    private void resultButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resultButtonActionPerformed
        subResult obj = new subResult();
        obj.setVisible(true);
    }//GEN-LAST:event_resultButtonActionPerformed

    private void admitcardButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_admitcardButtonActionPerformed
        Examdetail obj = new Examdetail();
        obj.setVisible(true);
    }//GEN-LAST:event_admitcardButtonActionPerformed

    private void logoutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutButtonActionPerformed
        smsGUI obj = new smsGUI();
        obj.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logoutButtonActionPerformed

    
    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton admButton;
    private javax.swing.JButton admitcardButton;
    private javax.swing.JButton classButton;
    private javax.swing.JButton feeReminderButton;
    private javax.swing.JButton feesubmitButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JButton logoutButton;
    private javax.swing.JButton managestdButton;
    private javax.swing.JButton resultButton;
    private javax.swing.JButton stdrecordButton;
    private javax.swing.JLabel username;
    // End of variables declaration//GEN-END:variables
}
