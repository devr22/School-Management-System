
import com.toedter.calendar.JTextFieldDateEditor;
import java.awt.event.KeyEvent;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JTextField;


public class admission extends javax.swing.JFrame {

    Connection con = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    
    JTextFieldDateEditor dtEditor;
    JTextFieldDateEditor dtEditor1;
    
    public admission() {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        ButtonGroup bg = new ButtonGroup();
        bg.add(jRadioButton1);
        bg.add(jRadioButton2);
        bg.add(jRadioButton3);
        
        try 
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@LAPTOP-I21KQA6O:1521:xe", "dev_school", "school2000");
        } 
        catch (Exception ex)
        {
            System.out.println(ex);
        }
        
         fillclasscomboBox();
         initDateEditor();
                 
    }

    private void initDateEditor(){
        dtEditor = (JTextFieldDateEditor)dobChooser.getDateEditor();
        dtEditor.setEditable(false);
        dtEditor1 = (JTextFieldDateEditor)doaChooser.getDateEditor();
        dtEditor1.setEditable(false);
    }
    
    
    private void fillclasscomboBox(){
        try{
            String query = "select distinct class from classdetail";
            pst =con.prepareStatement(query);
            rs = pst.executeQuery();
            
            while(rs.next()){
                String c = rs.getString("class");
                classComboBox.addItem(c);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void fillsectioncomboBox(){
              
        sectionComboBox.removeAllItems();
        try{
            String query = "select section from classdetail where class='"+classComboBox.getSelectedItem().toString()+"'";
            pst =con.prepareStatement(query);
            rs = pst.executeQuery();
                         
            while(rs.next()){
                String s = rs.getString("section");
                sectionComboBox.addItem(s);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public String getGender(){
       if(jRadioButton1.isSelected()){
           return "Male";
       }
       else if(jRadioButton2.isSelected()){
           return "Female";
       }
       else{
           return "Other";
       }
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        bgPanel = new javax.swing.JPanel();
        headingLabel = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        FnameLabel = new javax.swing.JLabel();
        fnameTxt = new javax.swing.JTextField();
        MnameLabel = new javax.swing.JLabel();
        MnameTxt = new javax.swing.JTextField();
        LnameLabel = new javax.swing.JLabel();
        LnameTxt = new javax.swing.JTextField();
        genderLabel = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        dobLabel = new javax.swing.JLabel();
        mobNoLabel = new javax.swing.JLabel();
        mobTxt = new javax.swing.JTextField();
        classLabel1 = new javax.swing.JLabel();
        sectionLabel = new javax.swing.JLabel();
        dobChooser = new com.toedter.calendar.JDateChooser();
        sectionComboBox = new javax.swing.JComboBox<>();
        classComboBox = new javax.swing.JComboBox<>();
        admissionLabel = new javax.swing.JLabel();
        admTxt = new javax.swing.JTextField();
        jRadioButton3 = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        nationalityLabel = new javax.swing.JLabel();
        NationTxt = new javax.swing.JTextField();
        fatherNameLabel = new javax.swing.JLabel();
        FatherTxt = new javax.swing.JTextField();
        motherNameLabel = new javax.swing.JLabel();
        MotherTxt = new javax.swing.JTextField();
        stateLabel = new javax.swing.JLabel();
        StateTxt = new javax.swing.JTextField();
        stateLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        AddTxt = new javax.swing.JTextArea();
        AdharLabel = new javax.swing.JLabel();
        AdharTxt = new javax.swing.JTextField();
        sssTxt = new javax.swing.JTextField();
        sssmidLabel = new javax.swing.JLabel();
        categoryLabel = new javax.swing.JLabel();
        categoryComboBox = new javax.swing.JComboBox<>();
        resetButton = new javax.swing.JButton();
        submitButton = new javax.swing.JButton();
        nextButton = new javax.swing.JButton();
        daolabel = new javax.swing.JLabel();
        doaChooser = new com.toedter.calendar.JDateChooser();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bgPanel.setBackground(new java.awt.Color(204, 204, 204));
        bgPanel.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 153, 153)));

        headingLabel.setFont(new java.awt.Font("Times New Roman", 1, 32)); // NOI18N
        headingLabel.setForeground(new java.awt.Color(80, 99, 244));
        headingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        headingLabel.setText("STUDENT ADMISSION ");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        FnameLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        FnameLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FnameLabel.setText("First Name");

        fnameTxt.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        fnameTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fnameTxtKeyReleased(evt);
            }
        });

        MnameLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        MnameLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MnameLabel.setText("Middle Name");

        MnameTxt.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        MnameTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                MnameTxtKeyReleased(evt);
            }
        });

        LnameLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        LnameLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LnameLabel.setText("Last Name");

        LnameTxt.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        LnameTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                LnameTxtKeyReleased(evt);
            }
        });

        genderLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        genderLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        genderLabel.setText("Gender");

        jRadioButton1.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        jRadioButton1.setText("Male");
        jRadioButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        jRadioButton2.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        jRadioButton2.setText("Female");
        jRadioButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        dobLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        dobLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dobLabel.setText("D.O.B");

        mobNoLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        mobNoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobNoLabel.setText("Mob No.");

        mobTxt.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        mobTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                mobTxtKeyPressed(evt);
            }
        });

        classLabel1.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        classLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        classLabel1.setText("Class");

        sectionLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        sectionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        sectionLabel.setText("Section");

        dobChooser.setDateFormatString("dd /MM/ yyyy");
        dobChooser.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        dobChooser.setMinSelectableDate(new java.util.Date(-62135785739000L));

        sectionComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select" }));
        sectionComboBox.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        classComboBox.setMaximumRowCount(50);
        classComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select" }));
        classComboBox.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        classComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                classComboBoxItemStateChanged(evt);
            }
        });

        admissionLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        admissionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        admissionLabel.setText("Adm No.");

        admTxt.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        admTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                admTxtKeyPressed(evt);
            }
        });

        jRadioButton3.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        jRadioButton3.setText("Other");
        jRadioButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(genderLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jRadioButton1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jRadioButton2)
                                        .addGap(39, 39, 39)
                                        .addComponent(jRadioButton3))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(admissionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(33, 33, 33)
                                        .addComponent(admTxt))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(classLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(sectionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(4, 4, 4)
                                        .addComponent(mobNoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(17, 17, 17)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(mobTxt)
                                    .addComponent(classComboBox, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(sectionComboBox, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(dobLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap(28, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(LnameLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(FnameLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(MnameLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE))))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(fnameTxt)
                            .addComponent(MnameTxt)
                            .addComponent(LnameTxt)
                            .addComponent(dobChooser, javax.swing.GroupLayout.DEFAULT_SIZE, 309, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(admissionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(admTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fnameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(FnameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MnameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(MnameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LnameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LnameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButton1)
                    .addComponent(genderLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRadioButton2)
                    .addComponent(jRadioButton3))
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(dobLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dobChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(classLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(classComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(sectionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sectionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mobNoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mobTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        nationalityLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        nationalityLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nationalityLabel.setText("Nationality");

        NationTxt.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        NationTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                NationTxtKeyReleased(evt);
            }
        });

        fatherNameLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        fatherNameLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        fatherNameLabel.setText("Father Name");

        FatherTxt.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        FatherTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                FatherTxtKeyReleased(evt);
            }
        });

        motherNameLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        motherNameLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        motherNameLabel.setText("Mother Name");

        MotherTxt.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        MotherTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                MotherTxtKeyReleased(evt);
            }
        });

        stateLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        stateLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        stateLabel.setText("State");

        StateTxt.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        StateTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                StateTxtKeyReleased(evt);
            }
        });

        stateLabel1.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        stateLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        stateLabel1.setText("Address");

        AddTxt.setColumns(20);
        AddTxt.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        AddTxt.setRows(5);
        AddTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                AddTxtKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(AddTxt);

        AdharLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        AdharLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        AdharLabel.setText("Adhar No.");

        AdharTxt.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        AdharTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                AdharTxtKeyPressed(evt);
            }
        });

        sssTxt.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        sssTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                sssTxtKeyPressed(evt);
            }
        });

        sssmidLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        sssmidLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        sssmidLabel.setText("SSSMID No.");

        categoryLabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        categoryLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        categoryLabel.setText("Category");

        categoryComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Gen", "OBC", "SC", "ST" }));
        categoryComboBox.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(fatherNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(FatherTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(nationalityLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(stateLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(stateLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(AdharLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(sssmidLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(motherNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(categoryLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(NationTxt)
                            .addComponent(MotherTxt)
                            .addComponent(StateTxt)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 309, Short.MAX_VALUE)
                            .addComponent(AdharTxt, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(sssTxt, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(categoryComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(42, 42, 42))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fatherNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(FatherTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MotherTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(motherNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(categoryLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(categoryComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nationalityLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(NationTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(stateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(StateTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(stateLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AdharTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AdharLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sssTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sssmidLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        resetButton.setBackground(new java.awt.Color(255, 51, 102));
        resetButton.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        resetButton.setText("Reset");
        resetButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        resetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetButtonActionPerformed(evt);
            }
        });

        submitButton.setBackground(new java.awt.Color(51, 255, 51));
        submitButton.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        submitButton.setText("Submit");
        submitButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        submitButton.setEnabled(false);
        submitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButtonActionPerformed(evt);
            }
        });

        nextButton.setBackground(new java.awt.Color(102, 102, 255));
        nextButton.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        nextButton.setText("Next");
        nextButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });

        daolabel.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        daolabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        daolabel.setText("Date of Admission");

        doaChooser.setDateFormatString("dd /MM/ yyyy");

        javax.swing.GroupLayout bgPanelLayout = new javax.swing.GroupLayout(bgPanel);
        bgPanel.setLayout(bgPanelLayout);
        bgPanelLayout.setHorizontalGroup(
            bgPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(nextButton, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(118, 118, 118)
                .addComponent(resetButton, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(103, 103, 103)
                .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(105, 105, 105))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgPanelLayout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
                .addGroup(bgPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 502, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(bgPanelLayout.createSequentialGroup()
                        .addComponent(daolabel, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(doaChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(53, 53, 53))
            .addGroup(bgPanelLayout.createSequentialGroup()
                .addGap(382, 382, 382)
                .addComponent(headingLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        bgPanelLayout.setVerticalGroup(
            bgPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgPanelLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(headingLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(bgPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(doaChooser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(daolabel, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(bgPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(bgPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(resetButton, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nextButton, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(bgPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bgPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void resetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetButtonActionPerformed
        submitButton.setEnabled(false);
        
        admTxt.setText("");
        fnameTxt.setText("");
        MnameTxt.setText("");
        LnameTxt.setText("");
        FatherTxt.setText("");
        MotherTxt.setText("");
        mobTxt.setText("");
        NationTxt.setText("");
        StateTxt.setText("");
        AdharTxt.setText("");
        sssTxt.setText("");
        
        
        AddTxt.setText("");
        jRadioButton1.setSelected(false);
        jRadioButton2.setSelected(false);
        
        classComboBox.setSelectedIndex(0);
        sectionComboBox.setSelectedIndex(0);
        categoryComboBox.setSelectedIndex(0);
        
        dobChooser.setCalendar(null);
        doaChooser.setCalendar(null);
    }//GEN-LAST:event_resetButtonActionPerformed

    private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
      
       
       if((!doaChooser.getCalendar().equals(null) && !dobChooser.getCalendar().equals(null) && classComboBox.getSelectedIndex()!= 0 && categoryComboBox.getSelectedIndex()!= 0 &&!AddTxt.getText().trim().isEmpty() && !admTxt.getText().trim().isEmpty() && !fnameTxt.getText().trim().isEmpty() && !LnameTxt.getText().trim().isEmpty() && !FatherTxt.getText().trim().isEmpty() && !MotherTxt.getText().trim().isEmpty() && !mobTxt.getText().trim().isEmpty() && !NationTxt.getText().trim().isEmpty() && !StateTxt.getText().trim().isEmpty() && !AdharTxt.getText().trim().isEmpty() && !sssTxt.getText().trim().isEmpty())&& (jRadioButton1.isSelected() || jRadioButton2.isSelected() || jRadioButton3.isSelected())){
           submitButton.setEnabled(true);
       }       
       else{
           JOptionPane.showMessageDialog(null, "**TextFields are not filled !");
       }
       
    }//GEN-LAST:event_nextButtonActionPerformed

    private void mobTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mobTxtKeyPressed
        
        int length = mobTxt.getText().length();
        char c = evt.getKeyChar();
        
        if(c >= '0' && c<= '9')
        {
            if(length < 10){
                mobTxt.setEditable(true);
            }
            else{
                mobTxt.setEditable(false);
            }
        }
        else{
            if(evt.getExtendedKeyCode()== KeyEvent.VK_BACK_SPACE || evt.getExtendedKeyCode()== KeyEvent.VK_DELETE){
                mobTxt.setEditable(true);
            }
            else{
                mobTxt.setEditable(false);
            }
        }
        
    }//GEN-LAST:event_mobTxtKeyPressed

    private void AdharTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_AdharTxtKeyPressed
        
        int length = AdharTxt.getText().length();
        char c = evt.getKeyChar();
        
        if(c >= '0' && c<= '9')
        {
            if(length < 12){
                AdharTxt.setEditable(true);
            }
            else{
                AdharTxt.setEditable(false);
            }
        }
        else{
            if(evt.getExtendedKeyCode()== KeyEvent.VK_BACK_SPACE || evt.getExtendedKeyCode()== KeyEvent.VK_DELETE){
                AdharTxt.setEditable(true);
            }
            else{
                AdharTxt.setEditable(false);
            }
        }
        
    }//GEN-LAST:event_AdharTxtKeyPressed

    private void sssTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_sssTxtKeyPressed
        
        char c = evt.getKeyChar();
        
        if(c >= '0' && c<= '9')
        {
            sssTxt.setEditable(true);
        }
        else{
            if(evt.getExtendedKeyCode()== KeyEvent.VK_BACK_SPACE || evt.getExtendedKeyCode()== KeyEvent.VK_DELETE){
                sssTxt.setEditable(true);
            }
            else{
                sssTxt.setEditable(false);
            }
        }
    }//GEN-LAST:event_sssTxtKeyPressed

    private void admTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_admTxtKeyPressed
        
        char c = evt.getKeyChar();
        
        if(c >= '0' && c<= '9')
        {
            admTxt.setEditable(true);
        }
        else{
            if(evt.getExtendedKeyCode()== KeyEvent.VK_BACK_SPACE || evt.getExtendedKeyCode()== KeyEvent.VK_DELETE){
                admTxt.setEditable(true);
            }
            else{
                admTxt.setEditable(false);
            }
        }
        
    }//GEN-LAST:event_admTxtKeyPressed

    private void classComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_classComboBoxItemStateChanged
        fillsectioncomboBox();
    }//GEN-LAST:event_classComboBoxItemStateChanged

    private void fnameTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fnameTxtKeyReleased
        int position = fnameTxt.getCaretPosition();
        fnameTxt.setText(fnameTxt.getText().toUpperCase());
        fnameTxt.setCaretPosition(position);
    }//GEN-LAST:event_fnameTxtKeyReleased

    private void MnameTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_MnameTxtKeyReleased
        int position = MnameTxt.getCaretPosition();
        MnameTxt.setText(MnameTxt.getText().toUpperCase());
        MnameTxt.setCaretPosition(position);
    }//GEN-LAST:event_MnameTxtKeyReleased

    private void LnameTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LnameTxtKeyReleased
        int position = LnameTxt.getCaretPosition();
        LnameTxt.setText(LnameTxt.getText().toUpperCase());
        LnameTxt.setCaretPosition(position);
    }//GEN-LAST:event_LnameTxtKeyReleased

    private void FatherTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_FatherTxtKeyReleased
        int position = FatherTxt.getCaretPosition();
        FatherTxt.setText(FatherTxt.getText().toUpperCase());
        FatherTxt.setCaretPosition(position);
    }//GEN-LAST:event_FatherTxtKeyReleased

    private void MotherTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_MotherTxtKeyReleased
        int position = MotherTxt.getCaretPosition();
        MotherTxt.setText(MotherTxt.getText().toUpperCase());
        MotherTxt.setCaretPosition(position);
    }//GEN-LAST:event_MotherTxtKeyReleased

    private void NationTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_NationTxtKeyReleased
        int position = NationTxt.getCaretPosition();
        NationTxt.setText(NationTxt.getText().toUpperCase());
        NationTxt.setCaretPosition(position);
    }//GEN-LAST:event_NationTxtKeyReleased

    private void StateTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_StateTxtKeyReleased
        int position = StateTxt.getCaretPosition();
        StateTxt.setText(StateTxt.getText().toUpperCase());
        StateTxt.setCaretPosition(position);
    }//GEN-LAST:event_StateTxtKeyReleased

    private void AddTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_AddTxtKeyReleased
        int position = AddTxt.getCaretPosition();
        AddTxt.setText(AddTxt.getText().toUpperCase());
        AddTxt.setCaretPosition(position);
    }//GEN-LAST:event_AddTxtKeyReleased

    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
       
        try{
            String query = "insert into admission values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            pst = con.prepareStatement(query);
            
            pst.setString(1, admTxt.getText());
            pst.setString(2, ((JTextField)doaChooser.getDateEditor().getUiComponent()).getText());
            pst.setString(3, fnameTxt.getText());
            pst.setString(4, MnameTxt.getText());
            pst.setString(5, LnameTxt.getText());
            pst.setString(6, getGender());
            pst.setString(7, ((JTextField)dobChooser.getDateEditor().getUiComponent()).getText());
            pst.setString(8, classComboBox.getSelectedItem().toString());
            pst.setString(9, sectionComboBox.getSelectedItem().toString()); 
            pst.setString(10, mobTxt.getText());
            pst.setString(11, FatherTxt.getText());
            pst.setString(12, MotherTxt.getText());
            pst.setString(13, categoryComboBox.getSelectedItem().toString());
            pst.setString(14, NationTxt.getText());
            pst.setString(15, StateTxt.getText());
            pst.setString(16, AddTxt.getText());
            pst.setString(17, AdharTxt.getText());
            pst.setString(18, sssTxt.getText());
            
            pst.executeQuery();
            
            JOptionPane.showMessageDialog(null, "Admission successful");
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, "Admission Unsuccessful"+ex);
        }
        
    }//GEN-LAST:event_submitButtonActionPerformed

    public static void main(String args[]) {
      
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admission.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admission.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admission.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admission.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admission().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea AddTxt;
    private javax.swing.JLabel AdharLabel;
    private javax.swing.JTextField AdharTxt;
    private javax.swing.JTextField FatherTxt;
    private javax.swing.JLabel FnameLabel;
    private javax.swing.JLabel LnameLabel;
    private javax.swing.JTextField LnameTxt;
    private javax.swing.JLabel MnameLabel;
    private javax.swing.JTextField MnameTxt;
    private javax.swing.JTextField MotherTxt;
    private javax.swing.JTextField NationTxt;
    private javax.swing.JTextField StateTxt;
    private javax.swing.JTextField admTxt;
    private javax.swing.JLabel admissionLabel;
    private javax.swing.JPanel bgPanel;
    private javax.swing.JComboBox<String> categoryComboBox;
    private javax.swing.JLabel categoryLabel;
    private javax.swing.JComboBox<String> classComboBox;
    private javax.swing.JLabel classLabel1;
    private javax.swing.JLabel daolabel;
    private com.toedter.calendar.JDateChooser doaChooser;
    private com.toedter.calendar.JDateChooser dobChooser;
    private javax.swing.JLabel dobLabel;
    private javax.swing.JLabel fatherNameLabel;
    private javax.swing.JTextField fnameTxt;
    private javax.swing.JLabel genderLabel;
    private javax.swing.JLabel headingLabel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel mobNoLabel;
    private javax.swing.JTextField mobTxt;
    private javax.swing.JLabel motherNameLabel;
    private javax.swing.JLabel nationalityLabel;
    private javax.swing.JButton nextButton;
    private javax.swing.JButton resetButton;
    private javax.swing.JComboBox<String> sectionComboBox;
    private javax.swing.JLabel sectionLabel;
    private javax.swing.JTextField sssTxt;
    private javax.swing.JLabel sssmidLabel;
    private javax.swing.JLabel stateLabel;
    private javax.swing.JLabel stateLabel1;
    private javax.swing.JButton submitButton;
    // End of variables declaration//GEN-END:variables
}
